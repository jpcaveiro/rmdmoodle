
library(devtools)

load_all("C:\\Users\\pedrocruz\\Documents\\GitHub\\rmdmoodle", reset=TRUE)
set_exercise_root("C:\\Users\\pedrocruz\\Documents\\GitHub\\WorkPackages\\2020-rmdmoodle\\testing_examples\\2024-01-18-teste-EB\\TESTE1_falhas")
setwd("C:\\Users\\pedrocruz\\Documents\\GitHub\\WorkPackages\\2020-rmdmoodle\\testing_examples\\2024-01-18-teste-EB")

#Construir o teste 2 do Turno 1
rmdexam("2023-2024-Teste2-turno1.Rmd", # nome do teste, para um turno, em Rmd
        c("c5-Associacao-GENERICO.Rmd", "Fisher01", "Qui01", "FWER01"),
        c("c5-McNemar-GENERICO.Rmd", "Conc01", "TH01"),
        c("c6-ANOVA-GENERICO.Rmd", "Frase01")
        #c("c6-ANOVAmedidasrepetidas-GENERICO.Rmd", "VF01", "Res01")  # Q 4
)

stop()

# #Construir o teste 2 do Turno 2
# rmdexam(3,"2023-2024-Teste2-turno2.Rmd", # nome do teste, para um turno, em Rmd
#         c("c5-Associacao-GENERICO.Rmd", "Fisher02", "Qui01", "FWER01"),  # Q 1
#         c("c5-McNemar-GENERICO.Rmd", "Conc02", "TH02"),  # Q 2
#         c("c6-ANOVA-GENERICO.Rmd", "Frase02"),  # Q 3
#         c("c6-ANOVAmedidasrepetidas-GENERICO.Rmd", "VF02", "Res01")  # Q 4
# )





##Construir o teste 1 do Turno 1
#rmdexam(3,"2023-2024-Teste1-turno1.Rmd", # nome do teste, para um turno, em Rmd
#        c("c4-RLmultipla-kidney.Rmd", "Est01", "TH01", "Pred01"),  # Q 1
#        c("c4-RLogSimples-GENERICO.Rmd", "R01", "Interp02", "xP01","xC01"),  # Q 2
#         c("c3-ACP-GENERICO.Rmd", "PV01", "TF03", "Prop02"),  # Q 3
#         c("c2-AC-kidney.Rmd", "Dend01", "Contar01", "Silh01","ACvar01")  # Q 4
#         )
#
#
# #Construir o teste 1 do Turno 2
# rmdexam(3,"2023-2024-Teste1-turno2.Rmd", # nome do teste, para um turno, em Rmd
#         c("c4-RLmultipla-kidney.Rmd", "Est02", "TH01", "Pred01"),  # Q 1
#         c("c4-RLogSimples-GENERICO.Rmd", "R01", "Interp02", "Px01","xC01"),  # Q 2
#         c("c3-ACP-GENERICO.Rmd", "PV01", "TF02", "Prop01"),  # Q 3
#         c("c2-AC-kidney.Rmd", "Dend02", "Contar02", "Silh02","ACvar01")  # Q 4
# )



