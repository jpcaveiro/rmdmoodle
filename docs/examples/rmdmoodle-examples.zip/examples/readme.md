Documentação

* https://jpcaveiro.github.io/rmdmoodle
* Pasta `com_banco_de_questoes` encontra-se um exemplo de um teste baseado em questões previamente construídas.
* Pasta `exame_em_ficheirounico` encontram-se exemplos de ficheiros `Rmd` contendo todo um teste Moodle.

